// import DummyDataTable from '../models/model.js';
// import axios from 'axios';


// export async function insertHandler(req, res) {
//   try {
//     let skip = 0;
//     const limit = 30;
//     let hasMoreData = true;

//     while (hasMoreData) {
//       // Fetch dummy data from the specified URL with pagination
//       const response = await axios.get(`https://dummyjson.com/products?limit=${limit}&skip=${skip}`);
//       const dummyData = response.data;

//       console.log(`Fetched ${dummyData.products.length} products`);

//       // Check if the response contains data
//       if (!dummyData || !dummyData.products || dummyData.products.length === 0) {
//         throw new Error("No data fetched from the external API");
//       }

//       // Extract the products array from dummyData
//       const products = dummyData.products;

//       // Insert each product
//       const insertPromises = products.map(async (product) => {
//         // Check if a product with the same id already exists in the database
//         const existingProduct = await DummyDataTable.findOne({ where: { id: product.id } });

//         // If the product doesn't exist, insert it into the database
//         if (!existingProduct) {
//           // Handle NULL or empty images array
//           let images = [];
//           if (product.images && product.images.length > 0 && !product.images.every(image => image === null)) {
//             // Filter out NULL values from the images array
//             images = product.images.filter(image => image !== null);
//           }

//           await DummyDataTable.create({
//             id: product.id,
//             title: product.title,
//             description: product.description,
//             price: product.price,
//             discountPercentage: product.discountPercentage,
//             rating: product.rating,
//             stock: product.stock,
//             brand: product.brand,
//             category: product.category,
//             thumbnail: product.thumbnail,
//             images: images // Use the original images array as it contains valid URLs
//           });
//         }
//       });

//       // Wait for all insertions in the current batch to complete
//       await Promise.all(insertPromises);

//       // Move to the next batch
//       skip += limit;

//       // If fewer than `limit` products were returned, we've reached the end of the data
//       if (products.length < limit) {
//         hasMoreData = false;
//       }
//     }

//     res.status(201).json({ result: "Data Inserted Successfully" });
//   } catch (error) {
//     console.error('Error inserting data:', error);
//     res.status(500).json({ error: error.message });
//   }
// }


// export async function fetchHandler(req, res) {
//   try {
//     const { limit, skip } = req.query || {};

//     let options = {};
//     if (limit) {
//       options.limit = parseInt(limit);
//     }
//     if (skip) {
//       options.offset = parseInt(skip);
//     }

//     const totalCount = await DummyDataTable.count();
//     const data = await DummyDataTable.findAll(options);

//     const response = {
//       products: data,
//       total: totalCount,
//       skip: parseInt(skip) || 0,
//       limit: parseInt(limit) || 10
//     };

//     res.status(200).json(response);
//   } catch (error) {
//     console.error('Error fetching data:', error);
//     res.status(500).json({ error: error.message });
//   }
// }

// export async function handleRoute(event) {
//   try {
//     let response;
//     switch (true) {
//       case event.route === "insert": {
//         response = await awsInsertHandler({ body: event.body });
//         break;
//       }
//       case event.route === "fetch": {
//         response = await awsFetchHandler({ query: event.queryStringParameters });
//         break;
//       }
//       default: {
//         response = {
//           statusCode: 500,
//           body: "Internal Server Error",
//         };
//       }
//     }
//     return response;
//   } catch (error) {
//     console.error('Error handling route:', error);
//     return {
//       statusCode: 500,
//       body: JSON.stringify({ error: "Internal Server Error" })
//     };
//   }
// }

// // Define the awsInsertHandler function for AWS context
// async function awsInsertHandler(event) {
//   try {
//     const data = JSON.parse(event.body);

//     if (!Array.isArray(data)) {
//       return {
//         statusCode: 400,
//         body: JSON.stringify({ error: "Input should be an array of records" })
//       };
//     }

//     console.log("Data inside insert:", data);

//     await DummyDataTable.bulkCreate(data);
//     return {
//       statusCode: 201,
//       body: JSON.stringify({ result: "Data Inserted Successfully" })
//     };
//   } catch (error) {
//     console.error('Error saving data:', error);
//     return {
//       statusCode: 500,
//       body: JSON.stringify({ error: error.message })
//     };
//   }
// }

// // Define the awsFetchHandler function for AWS context
// async function awsFetchHandler(event) {
//   try {
//     const { limit, skip } = event.query || {};

//     let options = {};
//     if (limit) {
//       options.limit = parseInt(limit);
//     }
//     if (skip) {
//       options.offset = parseInt(skip);
//     }

//     const totalCount = await DummyDataTable.count();
//     const data = await DummyDataTable.findAll(options);

//     const response = {
//       products: data,
//       total: totalCount,
//       skip: parseInt(skip) || 0,
//       limit: parseInt(limit) || 10
//     };

//     return {
//       statusCode: 200,
//       body: JSON.stringify(response)
//     };
//   } catch (error) {
//     console.error('Error fetching data:', error);
//     return {
//       statusCode: 500,
//       body: JSON.stringify({ error: error.message })
//     };
//   }
// }


import DummyDataTable from '../models/model.js';
import axios from 'axios';

// Original insertHandler
export async function insertHandler(req, res) {
  try {
    let skip = 0;
    const limit = 10;
    let hasMoreData = true;

    while (hasMoreData) {
      // Fetch dummy data from the specified URL with pagination
      const response = await axios.get(`https://dummyjson.com/products?limit=${limit}&skip=${skip}`);
      const dummyData = response.data;

      console.log(`Fetched ${dummyData.products.length} products`);

      // Check if the response contains data
      if (!dummyData || !dummyData.products || dummyData.products.length === 0) {
        throw new Error("No data fetched from the external API");
      }

      // Extract the products array from dummyData
      const products = dummyData.products;

      // Insert each product
      const insertPromises = products.map(async (product) => {
        // Check if a product with the same id already exists in the database
        const existingProduct = await DummyDataTable.findOne({ where: { id: product.id } });

        // If the product doesn't exist, insert it into the database
        if (!existingProduct) {
          // Handle NULL or empty images array
          let images = [];
          if (product.images && product.images.length > 0 && !product.images.every(image => image === null)) {
            // Filter out NULL values from the images array
            images = product.images.filter(image => image !== null);
          }

          await DummyDataTable.create({
            id: product.id,
            title: product.title,
            description: product.description,
            price: product.price,
            discountPercentage: product.discountPercentage,
            rating: product.rating,
            stock: product.stock,
            brand: product.brand,
            category: product.category,
            thumbnail: product.thumbnail,
            images: images // Use the original images array as it contains valid URLs
          });
        }
      });

      // Wait for all insertions in the current batch to complete
      await Promise.all(insertPromises);

      // Move to the next batch
      skip += limit;

      // If fewer than `limit` products were returned, we've reached the end of the data
      if (products.length < limit) {
        hasMoreData = false;
      }
    }

    res.status(201).json({ result: "Data Inserted Successfully" });
  } catch (error) {
    console.error('Error inserting data:', error);
    res.status(500).json({ error: error.message });
  }
}

// Original fetchHandler
export async function fetchHandler(req, res) {
  try {
    const { limit, skip } = req.query || {};

    let options = {};
    if (limit) {
      options.limit = parseInt(limit);
    }
    if (skip) {
      options.offset = parseInt(skip);
    }

    const totalCount = await DummyDataTable.count();
    const data = await DummyDataTable.findAll(options);

    const response = {
      products: data,
      total: totalCount,
      skip: parseInt(skip) || 0,
      limit: parseInt(limit) || 10
    };

    res.status(200).json(response);
  } catch (error) {
    console.error('Error fetching data:', error);
    res.status(500).json({ error: error.message });
  }
}

// HandleRoute function
export async function handleRoute(event) {
  try {
    let response;
    switch (true) {
      case event.route === "insert": {
        response = await awsInsertHandler({ body: event.body });
        break;
      }
      case event.route === "fetch": {
        response = await awsFetchHandler({ query: event.queryStringParameters });
        break;
      }
      default: {
        response = {
          statusCode: 500,
          body: "Internal Server Error",
        };
      }
    }
    return response;
  } catch (error) {
    console.error('Error handling route:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: "Internal Server Error" })
    };
  }
}

// AWS Insert Handler
async function awsInsertHandler(event) {
  try {
    let skip = 0;
    const limit = 30;
    let hasMoreData = true;

    while (hasMoreData) {
      // Fetch dummy data from the specified URL with pagination
      const response = await axios.get(`https://dummyjson.com/products?limit=${limit}&skip=${skip}`);
      const dummyData = response.data;

      console.log(`Fetched ${dummyData.products.length} products`);

      // Check if the response contains data
      if (!dummyData || !dummyData.products || dummyData.products.length === 0) {
        throw new Error("No data fetched from the external API");
      }

      // Extract the products array from dummyData
      const products = dummyData.products;

      // Insert each product
      const insertPromises = products.map(async (product) => {
        // Check if a product with the same id already exists in the database
        const existingProduct = await DummyDataTable.findOne({ where: { id: product.id } });

        // If the product doesn't exist, insert it into the database
        if (!existingProduct) {
          // Handle NULL or empty images array
          let images = [];
          if (product.images && product.images.length > 0 && !product.images.every(image => image === null)) {
            // Filter out NULL values from the images array
            images = product.images.filter(image => image !== null);
          }

          await DummyDataTable.create({
            id: product.id,
            title: product.title,
            description: product.description,
            price: product.price,
            discountPercentage: product.discountPercentage,
            rating: product.rating,
            stock: product.stock,
            brand: product.brand,
            category: product.category,
            thumbnail: product.thumbnail,
            images: images // Use the original images array as it contains valid URLs
          });
        }
      });

      // Wait for all insertions in the current batch to complete
      await Promise.all(insertPromises);

      // Move to the next batch
      skip += limit;

      // If fewer than `limit` products were returned, we've reached the end of the data
      if (products.length < limit) {
        hasMoreData = false;
      }
    }

    return {
      statusCode: 201,
      body: JSON.stringify({ result: "Data Inserted Successfully" })
    };
  } catch (error) {
    console.error('Error saving data:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: error.message })
    };
  }
}

// AWS Fetch Handler
async function awsFetchHandler(event) {
  try {
    const { limit, skip } = event.query || {};

    let options = {};
    if (limit) {
      options.limit = parseInt(limit);
    }
    if (skip) {
      options.offset = parseInt(skip);
    }

    const totalCount = await DummyDataTable.count();
    const data = await DummyDataTable.findAll(options);

    const response = {
      products: data,
      total: totalCount,
      skip: parseInt(skip) || 0,
      limit: parseInt(limit) || 10
    };

    return {
      statusCode: 200,
      body: JSON.stringify(response)
    };
  } catch (error) {
    console.error('Error fetching data:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: error.message })
    };
  }
}
