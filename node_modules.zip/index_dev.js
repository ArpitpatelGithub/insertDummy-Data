// index_dev.js
import express from 'express';
import sequelize from './models/db.js';
import * as Controller from './controller/controller.js';

const app = express();

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.post("/insert", Controller.insertHandler);
app.get("/fetch", Controller.fetchHandler);

async function initializeDatabase() {
  try {
    await sequelize.authenticate();
    console.log('Connection to database has been established successfully.');
    await sequelize.sync({ alter: true }); // Sync models with database
    console.log('Models synced successfully.');
  } catch (error) {
    console.error('Unable to connect to the database:', error);
  }
}

const PORT = 3000;
app.listen(PORT, async () => {
  console.log(`Server is running on http://localhost:${PORT}`);
  await initializeDatabase();
});
