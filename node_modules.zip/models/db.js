// This code is for creating static columns or perfom crud operation in coulmns which are avilable in tabel

import { Sequelize } from 'sequelize';

const sequelize = new Sequelize({
  database: 'db_sfsync', 
  username: 'postgres',
  password: '!2s6!YEdf6BrmkBf',
  host: 'sfsyncinstance-dev-28-02-2024.c5ixm26kc4nu.us-east-2.rds.amazonaws.com',
  port: 5432,
  dialect: 'postgres',
});

export default sequelize;
